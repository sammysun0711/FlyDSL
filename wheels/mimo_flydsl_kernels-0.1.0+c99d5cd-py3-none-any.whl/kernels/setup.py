# SPDX-License-Identifier: Apache-2.0

from setuptools import find_packages, setup


subpackages = find_packages(where=".")

setup(
    name="mimo-flydsl-kernels",
    version="0.1.0+c99d5cd",
    description="Validated FlyDSL kernel sources for MiMo-V2.5-Pro",
    packages=["kernels", *[f"kernels.{name}" for name in subpackages]],
    package_dir={"kernels": "."},
    package_data={
        "kernels.comm": ["mega_moe_tuning_config/*.json"],
    },
    python_requires=">=3.10",
)
